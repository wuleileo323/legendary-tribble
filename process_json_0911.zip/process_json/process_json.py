# parse_tencent_data.py

import json
import pandas as pd
import os
import re

def extract_job_title(job_str):

    return job_str.strip()

def split_concatenated_jsons(content):
    """
    分割拼接的 JSON 字符串，如：{}{}{} -> [{}, {}, {}]
    """
    content = content.strip()
    objects = []
    depth = 0
    start = -1

    for i, char in enumerate(content):
        if char == '{':
            if depth == 0:
                start = i
            depth += 1
        elif char == '}':
            if depth > 0:
                depth -= 1
                if depth == 0 and start != -1:
                    try:
                        obj = json.loads(content[start:i+1])
                        if isinstance(obj, dict):
                            objects.append(obj)
                        else:
                            print(f"⚠️ 提取的 JSON 不是对象：{obj}")
                    except json.JSONDecodeError as e:
                        print(f"⚠️ JSON 解析失败（{start}-{i+1}）: {e}")
    return objects

def main():
    input_file = '1.txt'
    output_file = 'processed_data.xlsx'

    if not os.path.exists(input_file):
        print(f"❌ 错误：找不到文件 {input_file}")
        return

    results = []

    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read().strip()

    if not content:
        print("⚠️ 文件为空")
        return

    # === 尝试多种解析方式 ===
    data = []

    # 1. 尝试整体解析为 JSON（数组或单对象）
    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict):
            data = [parsed]
        elif isinstance(parsed, list):
            data = parsed
        print(f"✅ 成功解析为完整 JSON（{len(data)} 项）")
    except json.JSONDecodeError:
        # 2. 按行解析
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        for line in lines:
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    data.append(obj)
            except json.JSONDecodeError:
                continue
        if data:
            print(f"✅ 成功按行解析（{len(data)} 项）")
        else:
            # 3. 尝试分割拼接的 JSON
            print("🟡 尝试解析拼接的 JSON...")
            data = split_concatenated_jsons(content)
            if data:
                print(f"✅ 成功分割拼接 JSON（{len(data)} 项）")
            else:
                print("❌ 所有解析方式均失败")
                return

    # === 提取数据并展开 links 为多列 ===
    for idx, person in enumerate(data):
        if not isinstance(person, dict):
            continue

        name = person.get("name", "").strip()

        jobs = person.get("jobs", [])

        job_title = str(jobs[0])

        # 初始化结果字典
        # 初始化结果字典
        row = {
            "name": name,
            "job": job_title,
            "last_job_change": (person.get("last_job_change") or "").strip()
        }
        
        # 提取 links 并按 key 展开为列
        links = person.get("links", {})
        if isinstance(links, dict):
            for key, url in links.items():
                if isinstance(url, str) and url.strip():
                    row[key] = url.strip()
                else:
                    row[key] = ""
        elif isinstance(links, (list, tuple)):
            for i, link in enumerate(links):
                if isinstance(link, str) and link.strip():
                    row[f"link_{i+1}"] = link.strip()
                else:
                    row[f"link_{i+1}"] = ""
        else:
            url_str = str(links).strip() if str(links).strip().lower() != 'none' else ''
            if url_str:
                row["link"] = url_str

        results.append(row)

    # === 动态生成列名：name + job + 所有出现过的 links 键 ===
    if not results:
        print("⚠️ 未解析到任何有效数据")
        return

    # 获取所有可能的列名（去重，保持顺序）
    columns = ["name", "job"]
    link_keys = set()
    for row in results:
        for key in row.keys():
            if key not in ("name", "job"):
                link_keys.add(key)
    columns += sorted(link_keys)  # 排序便于查看，也可用插入顺序

    # 创建 DataFrame
    df = pd.DataFrame(results)
    # 确保列顺序
    missing_cols = set(columns) - set(df.columns)
    for col in missing_cols:
        df[col] = ""
    df = df[columns]  # 重排顺序

    # 保存为 Excel
    try:
        df.to_excel(output_file, index=False)
        print(f"🎉 成功生成 Excel 文件：{output_file}")
        print(f"📊 共处理 {len(df)} 条记录，共 {len(df.columns)} 列")
        print("\n列名：", df.columns.tolist())
        print("\n预览前5行：")
        print(df.head())
    except Exception as e:
        print(f"❌ 保存 Excel 时出错：{e}")

if __name__ == "__main__":
    main()